// usage: node setup.js "email" "password"  -> writes .env (hashed password only, never plain text)
const fs=require('fs'),bcrypt=require('bcryptjs'),crypto=require('crypto');
const [,, email, pass]=process.argv;
if(!email||!pass||pass.length<10){console.log('usage: node setup.js <email> <password (10+ chars)>');process.exit(1)}
const hash=bcrypt.hashSync(pass,12);
fs.writeFileSync('.env',`ADMIN_EMAIL=${email}\nADMIN_HASH=${hash}\nJWT_SECRET=${crypto.randomBytes(48).toString('hex')}\nPORT=3000\n`,{mode:0o600});
console.log('.env created (chmod 600). Now: npm start');
