require('dotenv').config();
const express = require('express'), fs = require('fs'), path = require('path'), http = require('http');
const { spawn } = require('child_process');
const helmet = require('helmet'), rateLimit = require('express-rate-limit'), bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken'), cookieParser = require('cookie-parser'), multer = require('multer');
const { WebSocketServer } = require('ws'), AdmZip = require('adm-zip'), crypto = require('crypto');
const { ADMIN_EMAIL, ADMIN_HASH, JWT_SECRET, PORT = 3000 } = process.env;
if (!ADMIN_HASH || !JWT_SECRET) { console.error('Run first: node setup.js <email> <password>'); process.exit(1); }

const DATA = path.join(__dirname, 'data'), BOTS = path.join(DATA, 'bots'), TMP = path.join(DATA, 'tmp');
const BK = path.join(DATA, 'backups'), HF = path.join(DATA, 'hosts.json');
[BOTS, TMP, BK].forEach(d => fs.mkdirSync(d, { recursive: true }));
const load = () => { try { return JSON.parse(fs.readFileSync(HF)); } catch { return []; } };
const save = h => { fs.writeFileSync(HF + '.tmp', JSON.stringify(h, null, 2)); fs.renameSync(HF + '.tmp', HF); };

const LANGS = {
  node: m => ['node', [m]], python: m => ['python3', ['-u', m]], typescript: m => ['npx', ['tsx', m]],
  java: m => ['java', ['-jar', m]], go: m => ['go', ['run', m]], php: m => ['php', [m]], ruby: m => ['ruby', [m]],
  lua: m => ['lua', [m]], bash: m => ['bash', [m]], csharp: () => ['dotnet', ['run']], rust: () => ['cargo', ['run']]
};
const cleanEnv = extra => { const e = { ...process.env, ...extra }; delete e.ADMIN_HASH; delete e.JWT_SECRET; delete e.ADMIN_EMAIL; return e; };

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdnjs.cloudflare.com'],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://cdnjs.cloudflare.com', 'https://fonts.googleapis.com'],
  fontSrc: ["'self'", 'https://fonts.gstatic.com'], connectSrc: ["'self'", 'ws:', 'wss:'], imgSrc: ["'self'", 'data:'] } } }));
app.use(express.json({ limit: '5mb' }));
app.use(cookieParser());

const verify = t => { try { return jwt.verify(t, JWT_SECRET); } catch { return null; } };
const auth = (req, res, next) => verify(req.cookies.tk) ? next() : res.status(401).json({ error: 'unauthorized' });

app.post('/api/login', rateLimit({ windowMs: 15 * 60e3, max: 5, message: { error: 'محاولات كثيرة، حاول بعد 15 دقيقة' } }), async (req, res) => {
  const { email = '', password = '' } = req.body || {};
  const okMail = email.length === ADMIN_EMAIL.length && crypto.timingSafeEqual(Buffer.from(email), Buffer.from(ADMIN_EMAIL));
  const okPass = await bcrypt.compare(String(password), ADMIN_HASH);
  if (!okMail || !okPass) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  const tk = jwt.sign({ u: 1 }, JWT_SECRET, { expiresIn: '12h' });
  res.cookie('tk', tk, { httpOnly: true, sameSite: 'strict', secure: req.secure, maxAge: 12 * 3600e3 });
  res.json({ ok: 1 });
});
app.post('/api/logout', (req, res) => { res.clearCookie('tk'); res.json({ ok: 1 }); });
app.get('/api/me', auth, (req, res) => res.json({ ok: 1 }));

// ---- hosts (max 1)
app.get('/api/hosts', auth, (req, res) => res.json(load().map(h => ({ ...h, running: !!proc }))));
app.post('/api/hosts', auth, (req, res) => {
  if (load().length >= 1) return res.status(400).json({ error: 'الحد الأقصى استضافة واحدة' });
  const { name, lang } = req.body || {};
  if (!name || !LANGS[lang]) return res.status(400).json({ error: 'بيانات ناقصة' });
  const h = { id: crypto.randomBytes(6).toString('hex'), name: String(name).slice(0, 40), lang,
    main: lang === 'python' ? 'main.py' : lang === 'node' ? 'index.js' : '', env: '', created: Date.now() };
  fs.mkdirSync(path.join(BOTS, h.id), { recursive: true }); save([h]); res.json(h);
});
app.patch('/api/host', auth, (req, res) => {
  const hs = load(); if (!hs[0]) return res.status(404).end();
  const { name, lang, main, env } = req.body || {};
  if (name) hs[0].name = String(name).slice(0, 40);
  if (lang && LANGS[lang]) hs[0].lang = lang;
  if (typeof main === 'string') hs[0].main = main.replace(/\.\.|^[/\\]+/g, '');
  if (typeof env === 'string') hs[0].env = env;
  save(hs); res.json(hs[0]);
});
app.delete('/api/host', auth, (req, res) => {
  const h = load()[0]; if (!h) return res.status(404).end();
  stop(); fs.rmSync(path.join(BOTS, h.id), { recursive: true, force: true }); save([]); res.json({ ok: 1 });
});

// ---- process + console
let proc = null, logs = [];
const wss = new WebSocketServer({ noServer: true });
const bc = o => wss.clients.forEach(c => c.readyState === 1 && c.send(JSON.stringify(o)));
const emit = (d, e) => { logs.push({ d, e }); if (logs.length > 800) logs.shift(); bc({ t: 'log', d, e }); };
const status = () => bc({ t: 'status', running: !!proc });
const envOf = h => Object.fromEntries((h.env || '').split('\n').map(l => l.match(/^\s*([A-Za-z_]\w*)\s*=\s*(.*)$/)).filter(Boolean).map(m => [m[1], m[2]]));
const dirOf = h => path.join(BOTS, h.id);

function start() {
  const h = load()[0];
  if (proc) return 'running';
  if (!h) return 'no host';
  if (!['csharp', 'rust'].includes(h.lang) && (!h.main || !fs.existsSync(path.join(dirOf(h), h.main)))) {
    emit(`Error: الملف الأساسي "${h.main || '(غير محدد)'}" غير موجود. حدده من إعدادات الاستضافة.\n`, 1); return;
  }
  const [cmd, args] = LANGS[h.lang](h.main);
  emit(`$ ${cmd} ${args.join(' ')}\n`);
  proc = spawn(cmd, args, { cwd: dirOf(h), env: cleanEnv(envOf(h)) });
  proc.stdout.on('data', d => emit(d.toString()));
  proc.stderr.on('data', d => emit(d.toString(), 1));
  proc.on('error', e => { emit(`Error: ${e.message}\n`, 1); proc = null; status(); });
  proc.on('close', (c, s) => { emit(`\n[process exited code=${c} signal=${s}]\n`, c ? 1 : 0); proc = null; status(); });
  status();
}
function stop() { return new Promise(r => { if (!proc) return r(); const p = proc; p.once('close', () => r()); p.kill('SIGTERM'); setTimeout(() => p.kill('SIGKILL'), 5000); }); }
app.post('/api/start', auth, (req, res) => { start(); res.json({ ok: 1 }); });
app.post('/api/stop', auth, async (req, res) => { await stop(); res.json({ ok: 1 }); });
app.post('/api/restart', auth, async (req, res) => { await stop(); start(); res.json({ ok: 1 }); });
app.post('/api/term', auth, (req, res) => {
  const h = load()[0]; const cmd = String((req.body || {}).cmd || '').slice(0, 2000);
  if (!h || !cmd) return res.status(400).end();
  emit(`$ ${cmd}\n`);
  const p = spawn('sh', ['-c', cmd], { cwd: dirOf(h), env: cleanEnv(envOf(h)) });
  const t = setTimeout(() => p.kill('SIGKILL'), 10 * 60e3);
  p.stdout.on('data', d => emit(d.toString())); p.stderr.on('data', d => emit(d.toString(), 1));
  p.on('close', c => { clearTimeout(t); emit(`[done code=${c}]\n`); }); p.on('error', e => emit(e.message + '\n', 1));
  res.json({ ok: 1 });
});

// ---- files
const safe = rel => {
  const h = load()[0]; if (!h) throw new Error('no host');
  const base = dirOf(h), p = path.resolve(base, '.' + path.sep + String(rel || ''));
  if (p !== base && !p.startsWith(base + path.sep)) throw new Error('bad path');
  return p;
};
const wrap = fn => (req, res) => { try { fn(req, res); } catch (e) { res.status(400).json({ error: e.message }); } };
const up = multer({ dest: TMP, limits: { fileSize: 200 * 1024 * 1024 } });
app.get('/api/files', auth, wrap((req, res) => {
  const p = safe(req.query.path);
  res.json(fs.readdirSync(p, { withFileTypes: true }).map(d => ({ name: d.name, dir: d.isDirectory(), size: d.isDirectory() ? 0 : fs.statSync(path.join(p, d.name)).size }))
    .sort((a, b) => b.dir - a.dir || a.name.localeCompare(b.name)));
}));
app.get('/api/file', auth, wrap((req, res) => { const p = safe(req.query.path); if (fs.statSync(p).size > 5e6) throw new Error('الملف كبير'); res.json({ content: fs.readFileSync(p, 'utf8') }); }));
app.put('/api/file', auth, wrap((req, res) => { const p = safe(req.body.path); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, String(req.body.content ?? '')); res.json({ ok: 1 }); }));
app.post('/api/mkdir', auth, wrap((req, res) => { fs.mkdirSync(safe(req.body.path), { recursive: true }); res.json({ ok: 1 }); }));
app.post('/api/delete', auth, wrap((req, res) => { const p = safe(req.body.path); if (p === safe('')) throw new Error('no'); fs.rmSync(p, { recursive: true, force: true }); res.json({ ok: 1 }); }));
app.post('/api/move', auth, wrap((req, res) => { const a = safe(req.body.from), b = safe(req.body.to); fs.mkdirSync(path.dirname(b), { recursive: true }); fs.renameSync(a, b); res.json({ ok: 1 }); }));
app.get('/api/download', auth, wrap((req, res) => {
  const p = safe(req.query.path);
  if (fs.statSync(p).isDirectory()) { const z = new AdmZip(); z.addLocalFolder(p); res.attachment(path.basename(p) + '.zip').send(z.toBuffer()); }
  else res.download(p);
}));
app.post('/api/upload', auth, up.array('files', 50), (req, res) => {
  try {
    const dir = safe(req.query.path); fs.mkdirSync(dir, { recursive: true });
    for (const f of req.files) { const dest = path.join(dir, path.basename(f.originalname)); fs.copyFileSync(f.path, dest); fs.unlinkSync(f.path); }
    res.json({ ok: 1 });
  } catch (e) { (req.files || []).forEach(f => fs.rmSync(f.path, { force: true })); res.status(400).json({ error: e.message }); }
});
app.post('/api/extract', auth, wrap((req, res) => {
  const p = safe(req.body.path), dest = path.dirname(p), base = safe('');
  const z = new AdmZip(p);
  for (const e of z.getEntries()) { const t = path.resolve(dest, e.entryName); if (t !== base && !t.startsWith(base + path.sep)) throw new Error('zip غير آمن'); }
  z.extractAllTo(dest, true); res.json({ ok: 1 });
}));

app.use(express.static(path.join(__dirname, 'public')));

// ---- backups (hourly, keep 12)
setInterval(() => {
  try {
    const h = load()[0]; if (!h) return;
    const z = new AdmZip(); z.addLocalFolder(dirOf(h), '', n => !/node_modules/.test(n));
    z.writeZip(path.join(BK, `bot-${Date.now()}.zip`)); fs.copyFileSync(HF, path.join(BK, 'hosts.json.bak'));
    fs.readdirSync(BK).filter(f => f.endsWith('.zip')).sort().slice(0, -12).forEach(f => fs.unlinkSync(path.join(BK, f)));
  } catch (e) { console.error('backup', e.message); }
}, 3600e3);

const server = http.createServer(app);
server.on('upgrade', (req, sock, head) => {
  const tk = (req.headers.cookie || '').match(/(?:^|;\s*)tk=([^;]+)/);
  const sameOrigin = !req.headers.origin || new URL(req.headers.origin).host === req.headers.host;
  if (!tk || !verify(tk[1]) || !sameOrigin) { sock.destroy(); return; }
  wss.handleUpgrade(req, sock, head, ws => { ws.send(JSON.stringify({ t: 'init', logs, running: !!proc })); });
});
process.on('SIGTERM', async () => { await stop(); process.exit(0); });
server.listen(PORT, process.env.HOST || '127.0.0.1', () => console.log('Panel on port ' + PORT));
